package com.tcm.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenBlackBankNoraRahhaliApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenBlackBankNoraRahhaliApplication.class, args);
	}

}
