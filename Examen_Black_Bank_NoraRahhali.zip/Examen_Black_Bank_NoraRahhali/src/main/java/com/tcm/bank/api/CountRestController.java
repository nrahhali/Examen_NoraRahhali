package com.tcm.bank.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.tcm.bank.application.UserController;
import com.tcm.bank.persistance.CountRepository;
import com.tcm.bank.utilities.NotFoundException;

public class CountRestController {
	 @GetMapping("/counts")
	 public String getAllCounts() {
		 String allCounts = new CountRepository().getAllCounts();
		 return allCounts;
	 }
	 
	 
	 @GetMapping("/counts/{id}")
	 public String getCount(@PathVariable String IBAN) throws NotFoundException {
		 String count = new CountRepository().getCount(IBAN);
		 return count;
	 }
}
