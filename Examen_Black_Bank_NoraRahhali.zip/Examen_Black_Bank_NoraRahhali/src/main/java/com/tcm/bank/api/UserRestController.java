package com.tcm.bank.api;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.tcm.bank.application.UserController;
import com.tcm.bank.utilities.NotFoundException;





@RestController
public class UserRestController {
	
	 @GetMapping("/users")
	 public String getAllUsers() {
		 String allUsers = new UserController().getAllUsers();
		 return allUsers;
	 }
	 
	 
	 @GetMapping("/users/{id}")
	 public String getUser(@PathVariable String id) throws NotFoundException {
		 String user = new UserController().getUser(id);
		 return user;
	 }
	 
	 
	 
	 
	 
}
