package com.tcm.bank.application;

import java.util.ArrayList;
import java.util.List;

import com.tcm.bank.application.dto.CountDTO;
import com.tcm.bank.application.dto.UserDTO;
import com.tcm.bank.domain.Count;
import com.tcm.bank.domain.User;
import com.tcm.bank.persistance.CountRepository;
import com.tcm.bank.persistance.UserRepository;
import com.tcm.bank.utilities.InvalidParamException;

public class CountController {
	
	public CountDTO createCount(CountDTO countDTO) throws Exception{
		Count count = new Count(countDTO);
		CountRepository.storeCount(count);
		return new CountDTO(count);
	}
	
	public CountDTO getCount(String IBAN) throws Exception{
		Count count = CountRepository.getCount(IBAN);
		return new CountDTO(count);
	}
	
	public List<CountDTO> getAllCounts() throws InvalidParamException {
		List<Count> allCounts = new UserRepository().getAllCounts();
		
		return convertUsersToDTO(allCounts);
	}

	private List<CountDTO> convertUsersToDTO(List<Count> allCounts) throws InvalidParamException {
		List<CountDTO> result = new ArrayList<>();
		
		for(Count count : allCounts) {
			result.add(new CountDTO(count));
		}
		return result;
	}

}
