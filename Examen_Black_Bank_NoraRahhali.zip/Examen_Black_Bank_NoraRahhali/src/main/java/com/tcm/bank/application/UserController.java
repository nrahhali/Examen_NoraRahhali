package com.tcm.bank.application;

import java.util.ArrayList;
import java.util.List;

import com.tcm.bank.application.dto.UserDTO;
import com.tcm.bank.domain.User;
import com.tcm.bank.persistance.UserRepository;
import com.tcm.bank.utilities.InvalidParamException;



public class UserController {
	
	public UserDTO createUser(UserDTO userDTO) throws Exception{
		User user = new User (userDTO);
		UserRepository.storeUser(user);
		return new UserDTO(user);
	}
	
	public UserDTO getUser(String id) throws Exception{
		User user = UserRepository.getUser(id);
		return new UserDTO(user);
	}
	
	public List<UserDTO> getAllUsers() throws InvalidParamException {
		List<User> allUsers = new UserRepository().getAllUsers();
		
		return convertUsersToDTO(allUsers);
	}

	private List<UserDTO> convertUsersToDTO(List<User> allUsers) throws InvalidParamException {
		List<UserDTO> result = new ArrayList<>();
		
		for(User user : allUsers) {
			result.add(new UserDTO(user));
		}
		return result;
	}
	
	
	public UserDTO updateUser(String userId, UserDTO userDTO) throws Exception{
		User user = UserRepository.getUser(userId);
		user.updateUser(userDTO);
		UserRepository.updateUser(user);
		return new UserDTO(user);
	}

	

}
