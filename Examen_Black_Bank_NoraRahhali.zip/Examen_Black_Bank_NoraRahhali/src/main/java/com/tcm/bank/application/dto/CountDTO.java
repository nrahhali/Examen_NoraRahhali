package com.tcm.bank.application.dto;

import com.tcm.bank.domain.Count;
import com.tcm.bank.utilities.InvalidParamException;

public class CountDTO {
	
	private String IBAN;
	private double money;
	
	public CountDTO(String IBAN, double money) throws Exception {		
		this.IBAN = IBAN;
		this.money = money;
	}
	
	public CountDTO(Count count) throws InvalidParamException {
		if(count==null) throw new InvalidParamException();
		this.IBAN = count.getIBAN();
		this.money = count.getMoney();
		
	}

}
