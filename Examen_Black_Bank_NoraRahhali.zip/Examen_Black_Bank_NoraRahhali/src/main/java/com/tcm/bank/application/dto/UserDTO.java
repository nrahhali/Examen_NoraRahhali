package com.tcm.bank.application.dto;

import java.util.Calendar;

import com.tcm.bank.domain.User;
import com.tcm.bank.utilities.InvalidParamException;

public class UserDTO {
	private String id;
	private String email;
	private String phone;
	private String username;
	private String password;
	private Calendar dateCreation;
	
	public UserDTO(String email, String phone, String username, String password, Calendar dateCreation) {
		this.email = email;
		this.phone = phone;
		this.username = username;
		this.password = password;
		this.dateCreation = dateCreation;
		
	}
	
	public UserDTO(User user) throws InvalidParamException{
		if(user==null) throw new InvalidParamException();
		
		this.id = user.getId();
		this.email = user.getEmail();
		this.phone = user.getPhone();
		this.username = user.getUsername();
		this.password = user.getPassword();
		this.dateCreation = user.getDateCreation();
	}
	
	public String getId() throws InvalidParamException{
		if(id == null || id.equals(""))
			throw new InvalidParamException();
		
		return id;
	}
	
	public String getEmail() throws InvalidParamException{
		if(email == null || email.equals(""))
			throw new InvalidParamException();
		
		return email;
	}
	
	public String getPhone() throws InvalidParamException{
		if(phone == null || phone.equals(""))
			throw new InvalidParamException();
		
		return phone;
	}
	
	public String getUsername() throws InvalidParamException{
		if(username == null || username.equals(""))
			throw new InvalidParamException();
		
		return username;
	}
	
	public String getPassword() throws InvalidParamException{
		if(password == null || password.equals(""))
			throw new InvalidParamException();
		
		return password;
	}
	
	public Calendar getDateCreation() throws InvalidParamException{
		if(dateCreation == null || dateCreation.equals(""))
			throw new InvalidParamException();
		
		return dateCreation;
	}

}
