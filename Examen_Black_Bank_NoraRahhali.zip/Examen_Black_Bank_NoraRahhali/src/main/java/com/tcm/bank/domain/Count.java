package com.tcm.bank.domain;

public class Count {
	
	private String IBAN;
	private double money;
	
	public Count(String IBAN, double money) throws Exception {
		if(IBAN == null)
			throw new Exception();
		
		this.IBAN = IBAN;
		this.money = money;
	}

	public String getIBAN() {
		return IBAN;
	}

	public double getMoney() {
		return money;
	}

}
