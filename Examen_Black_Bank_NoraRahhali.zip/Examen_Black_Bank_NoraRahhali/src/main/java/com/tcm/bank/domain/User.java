package com.tcm.bank.domain;

import java.util.Calendar;
import java.util.UUID;

import com.tcm.bank.application.dto.UserDTO;
import com.tcm.bank.utilities.InvalidParamException;


public class User {
	
	private String id;
	private String email;
	private String phone;
	private String username;
	private String password;
	private Calendar dateCreation;
	
	public User(String id, String email, String phone, String username, String password, Calendar dateCreation) throws Exception {
		if(id.equals("")) throw new Exception();
		
		if(email.equals("")) throw new Exception();
		
		if(phone.equals("")) throw new Exception();
		
		if(username.equals("")) throw new Exception();
		
		if(password.equals("")) throw new Exception();
		
		this.id = id;
		this.email = email;
		this.phone = phone;
		this.username = username;
		this.password = password;
		this.dateCreation = dateCreation;
	}
	
	public User(UserDTO userDTO) throws InvalidParamException {
		if(userDTO == null)
			throw new InvalidParamException();
		this.id = UUID.randomUUID().toString();
		this.email = userDTO.getEmail();
		this.phone = userDTO.getPhone();
		this.username = userDTO.getUsername();
		this.password = userDTO.getPassword();
		this.dateCreation = userDTO.getDateCreation();
		}
	
	
	
	public String getId() {
		return id;
	}
	
	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public Calendar getDateCreation() {
		return dateCreation;
	}

	
	
	public void setEmail(String email) throws Exception {
		if(email == null) throw new Exception();
		this.email = email;
	}

	public void setPhone(String phone) throws Exception {
		if(phone == null) throw new Exception();
		this.phone = phone;
	}

	public void setPassword(String password) throws Exception {
		
		int cont=0;

		for(int i=0; i < password.length(); i++) {
			if(password.charAt(i) >= 45 && password.charAt(i) <= 58 || password.charAt(i) >= 64 && password.charAt(i) <= 91 || password.charAt(i) >= 97 && password.charAt(i) <= 122)
				cont = i+1;
		}
		
		if(cont < 8 || password==null)
			throw new Exception("Invalid. The password must have minimum 8 digits.");
		this.password = password;
		
	}


	public void updateUser(UserDTO userDTO) throws InvalidParamException {
		if(userDTO == null)
			throw new InvalidParamException();
		
		this.email = userDTO.getEmail();
		this.phone = userDTO.getPhone();
		this.username = userDTO.getUsername();
		this.password = userDTO.getPassword();
		this.dateCreation = userDTO.getDateCreation();
		

	}
	

}
