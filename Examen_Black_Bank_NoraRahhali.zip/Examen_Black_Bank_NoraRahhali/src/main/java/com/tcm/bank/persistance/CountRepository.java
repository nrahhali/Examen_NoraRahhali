package com.tcm.bank.persistance;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.tcm.bank.domain.Count;
import com.tcm.bank.utilities.NotFoundException;

public class CountRepository {

	private static Set <Count> counts = new HashSet<>();
	
	public Count getCount(String IBAN) throws NotFoundException{
		for(Count count : counts) {
			if(count.getIBAN().equals(IBAN))
				return count;
		}
		throw new NotFoundException();
	}
	
	public List<Count> getAllUsers(){
		return new ArrayList<>(counts);
	}
	
	public void deleteCount(Count count) throws NotFoundException{
		boolean removed = counts.remove(count);
		if(!removed)
			throw new NotFoundException();
	}
	
	
}
