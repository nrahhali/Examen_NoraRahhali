package com.tcm.bank.persistance;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.tcm.bank.domain.User;
import com.tcm.bank.utilities.InvalidParamException;
import com.tcm.bank.utilities.NotFoundException;

public class UserRepository {
	
	private static Set <User> users = new HashSet<>();

	
	public static void storeUser(User user) throws Exception {		
		try {
			ConnectionBBDD connection = ConnectionRepository.getConnection();
			
			String sql = "Insert into BANK (ID, EMAIL, PHONE, USERNAME, PASSWORD) values (?, ?, ?, ?, ?, ?)";
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, user.getId());
			pst.setString(2, user.getEmail());
			pst.setString(3, user.getPhone());
			pst.setString(4, user.getUsername());
			pst.setString(5, user.getPassword());
			
			
			
			if(pst.executeUpdate() != 1)
				throw new InvalidParamException();
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new InvalidParamException();
		}
	}
	
	public static User getUser(String id) {
		ConnectionBBDD connection = ConnectionRepository.getConnection();
		
		try {
			String sql = "SELECT * FROM BANK WHERE ID=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.clearParameters();
			preparedStatement.setString(1, userId);
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				String id = rs.getString("ID");
				String email = rs.getString("EMAIL");
				String phone = rs.getString("PHONE");
				String username = rs.getString("USERNAME");
				String password = rs.getString("PASSWORD");
				Calendar dateCreation = rs.getDate();
				
				return new User(id, email, phone, username, password, dateCreation);
			}
			throw new NotFoundException();
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new InvalidParamException();
		}
	}
	
	
	public List<User> getAllUsers(){
		return new ArrayList<>(users);
	}
	
	public void deleteUser(String id) throws NotFoundException {
		for(User user : new ArrayList<>(users)) {
			if(user.getId().equals(id)) {
				users.remove(user);
				return;
			}
		}
		throw new NotFoundException();
	}	
	
	public static void updateUser(User user) throws Exception {
		ConnectionBBDD connection = ConnectionRepository.getConnection();
		
		try {
			String sql = "UPDATE PICTURES SET PASSWORD=?, PHONE=? WHERE EMAIL=?";
			PreparedStatement pst = connection.prepareStatement(sql);
			
			pst.clearParameters();
			pst.setString(1, user.getPassword());
			pst.setString(2, user.getPhone());
			pst.setString(3, user.getEmail());
			
			if(pst.executeUpdate() != 1)
				throw new NotFoundException();
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new InvalidParamException();
		}
	}
	
}
