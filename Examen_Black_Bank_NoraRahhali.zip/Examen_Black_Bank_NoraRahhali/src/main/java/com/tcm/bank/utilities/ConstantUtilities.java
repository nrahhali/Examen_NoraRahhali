package com.tcm.bank.utilities;


public class ConstantUtilities {

	public static final String USERNAME_BBDD = null;
	public static final String PASSWORD_BBDD = null;
	


}
