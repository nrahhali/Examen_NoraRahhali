package com.tcm.bank.view;

import com.pictures.app.application.dto.PictureDTO;
import com.tcm.bank.application.UserController;
import com.tcm.bank.application.dto.UserDTO;
import com.tcm.bank.domain.User;
import com.tcm.bank.persistance.UserRepository;

public class Main {
	private static UserController controller = new UserController();
	
	public static void main(String [] args) throws Exception {
		UserDTO user = createUser();
		updateUser(user.getId());
		getUser(user.getId());
	}

	
	private UserDTO createUser() throws Exception{
		UserDTO user = new UserDTO();
		user = controller.createUser(user);
		System.out.println(user);
		return user;
	}
	
	private static PictureDTO createPicture() throws Exception{
		PictureDTO picture = new PictureDTO("www.google.com/picasp.jpg", "picaso");
		picture = controller.createPicture(picture);
		System.out.println(picture);
		return picture;
	}
	
	private static void updateUser(String id) throws Exception{
		UserDTO user = new UserDTO();
		user = controller.updateUser(id, controller);
		System.out.println(user);
	}
	
	private static void getUser(String id) throws Exception{
		UserDTO user = controller.getUser(id);
		System.out.println(user);
	}

}
